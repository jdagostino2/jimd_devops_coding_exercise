name             'java8'
maintainer       'Shekhar Gulati'
maintainer_email 'shekhargulati84@gmail.com'
license          'all_rights'
description      'Installs/Configures java8'
long_description 'Installs/Configures java8'
version          '0.1.0'

depends 'java'
